#!/bin/sh

function log2() {
 s=1
 for ((q=1; q<=32; q=q+1)); do
  let s=s+s; if [ $1 -le $s ]; then echo $q; return; fi
 done
} 

prin=x64test
echo  $prin

prg4=ss23b2d
prg5=ss23b2i

for prg in  $prg0 $prg1 $prg2 $prg3 $prg4 $prg5 $prg6 $prg7 $prg8 $prg9 ; do
 gcc  -O1  -c $prg.c # -DDEBUG  -S -w  警告を抑制する場合に使用する  
 gcc  -O1 -fcommon -o $prg main_prog_antei.c $prg.o  # main_recsiz1c.c -finline-functions -funroll-all-loops _antei main_recsiz1c.c
 echo compile done   $prg   $prin
done
#echo "112288"
#exit

echo '------------------------------------  '  $0  "     "  $prin.txt  >>$prin.txt

 for s in  16 24 32 40 48 56 64 72 80 88 96 104 112 120 160 200 240 280 320 360 400 440 480 ; do 
  for e in 100 200 400  1000 2000 4000  10000 20000 40000  100000 200000 400000 1000000  ; do
      log2s=`log2 $s`
      for m in  0  ; do     # 0 2 4
        for d in  -3 32 16 11 8 6 5 4 3 2 ; do
        for prg in  $prg0 $prg1 $prg2 $prg3 $prg4 $prg5 $prg6 $prg7 $prg8 $prg9 ; do
          m2=`expr $m + 1`
          xx1=`expr $s \* 1 + $m2 \* 330 + 10`
          log2e=`log2 $e`
          xx2=`expr $e \* $log2e \* $xx1`
          d2=$d;            if [ $d2    -le 1 ]; then d2=1000000; fi
          log2d=`log2 $d2`; if [ $log2d -le 2 ]; then log2d=2; fi
          xx3=`expr $xx2 \* $log2d / 2000`; if [ $xx3 -le 1 ]; then xx3=1; fi
          xx4=`expr 400000000 / $xx3`
          edd=`expr $e / $d2`
          if [ $edd -gt 10 -a $s -ge 200 ]; then xx4=`expr 200000000 / $xx3`; fi
          repi2=`expr $xx4 \* 3`
          if [ $repi2 -lt 1 ]; then repi2=1; fi
          for ((j=1; j <= 1; j=j+1)); do
            time ./$prg   $d  $e   $s  $repi2     -1   -1   -1  $m  >>$prin.txt
          done #j
          if [ $j -ge 3 ]; then echo '-' >>$prin.txt; fi
        done #prg
        echo '*' >>$prin.txt
        done #d
        echo '**' >>$prin.txt
      done #m
  done #e
  echo '***' >>$prin.txt
 done #s
 echo '****' >>$prin.txt
echo '====================================  ' >>$prin.txt

exit
